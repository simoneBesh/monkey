var monkey, banana, obstacleGroup;
var monkeyAn, bananaImage, stoneImage; 
var score;
var background;
var ground;

function preload(){
  monkeyAn=loadAnimation("Monkey_01.png", "Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  bananaImage=loadImage("banana.png");
  background=loadImage("jungle.png");
}

function setup() {
  createCanvas(400, 400);
  background=createSprite(200, 200, 400, 400);
  background.velocityX=5;
  background.x=background.width/2;
  
  monkey=createSprite (50, 380, 10, 10);
  banana=createSprite (50, 380, 10, 10);
  
  ground=createSprite(200, 380, 400, 20);
  ground.visible=false;
  
  monkey.addAnimation(monkeyAn);
  
  score=0;
}

function draw() {
  background(220);
  
  monkey.collide(ground);
  
  ground.x=200;
  
  if (monkey.isTouching(banana)) {
    banana.destroy();
    score=score+2;
  }
  
  switch(monkey.score){
    case 10: monkey.scale=1.2;
      break;
    case 20: monkey.scale=1.4;
      break;
    case 30: monkey.scale=1.6;
      break;
    case 40: monkey.scale=1.8;
      break;
    case 50: monkey.scale=2;
      break;
    default: break;
  }
  
  if (obstacleGroup.isTouching(monkey)){
    monkey.scale=1;
  }
  
  drawSprites();
  
  textSize(20);
  text("Score: " + score, 350, 100);
}